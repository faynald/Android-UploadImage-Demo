<?php

// Connect to database
include("connection.php");
$db = new dbObj();
$connection =  $db->getConnstring();

$request_method=$_SERVER["REQUEST_METHOD"];

switch($request_method) {
    case 'POST':
        // Insert Product
        insert_image();
        break;
    case 'GET':
        get_image();
        break;
    default:
        // Invalid Request Method
        header("HTTP/1.0 405 Method Not Allowed");
        break;
}

function insert_image() {
    global $connection;

    // $data = json_decode(file_get_contents('php://input'), true);

    $name = $_POST["time"] . "_" . $_POST["name"]; // POST if using form-data, $data if using form-urlencoded
    // $time = $data["time"];

    $files = $_FILES['shitfile']['tmp_name'];
    $filesname= $_FILES['shitfile']['name'];
    $folder = "./images/" . $name . "_" . $filesname;

    $query="INSERT INTO tb_images SET user_id = '123', name ='".$name."_".$filesname."'";
    if(mysqli_query($connection, $query) && move_uploaded_file($files, $folder))
    {
        $response=array(
            'status' => 1,
            'status_message' =>'Image Upload Successfully.'
        );
    }
    else
    {
        $response=array(
            'status' => 0,
            'status_message' =>'Image Upload Failed.'
        );
    }
    header('Content-Type: application/json');
    echo json_encode($response);
}

function get_image() { // TODO : upload other images
    global $connection;
    $query = "SELECT * FROM tb_images";
    $response = array();
    $result = mysqli_query($connection, $query);
    while ($row = mysqli_fetch_assoc($result)) {
        $response[] = $row;
    }

    header('Content-Type: application/json');
    echo json_encode($response);

}

?>